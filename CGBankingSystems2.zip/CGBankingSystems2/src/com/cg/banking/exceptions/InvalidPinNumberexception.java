package com.cg.banking.exceptions;

public class InvalidPinNumberexception extends Exception {
	public InvalidPinNumberexception(String message) {
super(message);
	}
}
