package com.cg.banking.daoservices;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transactions;
import com.cg.banking.util.BankingDBUtil;

public class TransactionDAOImpl implements TransactionDAO {
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("JPA-PU");
	@Override
	public Transactions save(long accountNo, Transactions transaction) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(transaction);
		entityManager.getTransaction().commit();
		entityManager.close();
		return transaction;
	}

	@Override
	public boolean update(Transactions transaction) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(transaction);
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}

	@Override
	public List<Transactions> findOne(long accountNo) {
		return  entityManagerFactory.createEntityManager().createQuery("from Transactions t where t.account="+accountNo).getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Transactions> findAll() {
		return entityManagerFactory.createEntityManager().createQuery("from Transactions t").getResultList();
	}

}
