package com.cg.banking.client;

import java.util.Scanner;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.banking.beans.Account;
import com.cg.banking.daoservices.AccountDaoImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServiceDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberexception;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;


public class MainClass {
	EntityManagerFactory entityManager = Persistence.createEntityManagerFactory("JPA-PU");
	
	
	
	
	static Scanner sc= new Scanner(System.in);
	static BankingServices services=new BankingServicesImpl();

	public static void DriverProgram(){
		System.out.println("__________________________________Welcome to CapGemini Group Of Bank__________________________________");
		System.out.println("Please Select the Choices Given Below :");
		System.out.println("1. If New Customer Create Account");
		System.out.println("2. If Existing Customer Get your account details");
		System.out.println("3. Get All Account Details Of CapGemini Bank");
		System.out.println("4. Deposit Money With In CapGemini Bank");
		System.out.println("5. Withdraw Money With In Capgemini Bank ");
		System.out.println("6. Fund Transfer With In CapGemini Bank");
		System.out.println("7. Get one Account Transactions.");
		System.out.println("8. Get all Account Transaction Details");
		System.out.println("9. Exit\n\n");
	}

	public static void main(String args[]) throws InvalidAmountException, InvalidAccountTypeException, BankingServiceDownException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberexception {
		int userInput=0;
		do {
			DriverProgram();
			userInput=sc.nextInt();
			startMenu(userInput);
		}while(userInput!=8) ;

	}
	public static void startMenu(int userInput) throws InvalidAmountException, InvalidAccountTypeException, BankingServiceDownException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberexception {
		switch(userInput) {
		case 1: 
		System.out.println("Do You Want To Create Saving Accounts or Current Account ");
		String accType=sc.next();
		System.out.println("Enter Amount To Deposit Amount In Beginning Of Account Opening ");
		long initiBalance=sc.nextLong();
		long accountNo = services.openAccount(accType,initiBalance);
		System.out.println("Successful!Welcome to Capgemini Bank");
		System.out.println(accountNo);
		break;
		case 2:System.out.println("Enter the Account number");
		long accNumber=sc.nextLong();
		System.out.println(services.getAccountDetails(accNumber));
		break;
		case 3: System.out.println(services.getAllAccountDetails());
		break;
		case 4:  System.out.println("Enter the account number:");
		long accountNoDeposit = sc.nextLong();
		System.out.println("Enter the amount to deposit:");
		float amountToDeposit=sc.nextFloat();
		System.out.println(services.depositAmount(accountNoDeposit, amountToDeposit));
		break;
		case 5: System.out.println("Enter the Account Number to Withdraw Money:");
		long accountNoWithdraw = sc.nextLong();
		sc.nextLine();
		System.out.println("Enter the Amount to be Withdrawn from :"+accountNoWithdraw);
		float amountToWithdraw = sc.nextFloat();
		sc.nextLine();
		System.out.println("Please Enter the PIN Number  Of :"+accountNoWithdraw);
		int pinNumber = sc.nextInt();
		System.out.println(services.withdrawAmount(accountNoWithdraw, amountToWithdraw, pinNumber));
		break;
		case 6:System.out.println("Enter the Account  Number of Receiver:");
		long accountNoTo=sc.nextLong();
		sc.nextLine();
		System.out.println("Enter the Account Number of Depositer:");
		long accountNoFrom=sc.nextLong();
		sc.nextLine();
		System.out.println("Enter the Amount to be Transfered :");
		float transferAmount=sc.nextFloat();
		sc.nextLine();
		System.out.println("Enter the PIN Number :");
		int  pinNumber1=sc.nextInt();
		System.out.println(services.fundTransfer(accountNoTo, accountNoFrom, transferAmount, pinNumber1));
		break;
		case 7:System.out.println("Enter account number");
		long accountNumber = sc.nextLong();
			System.out.println(services.getOneAllTransactions(accountNumber));
			break;
		case 8:	System.out.println(services.getAccountAllTransactions());
						break;
		case 9:System.out.println("Program is Closed");
		System.exit(0);

		default: 
			System.out.println("Invalid Choice,Please Try Again!!!!!!");
		}


	}
	
}