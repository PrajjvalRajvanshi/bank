package com.cg.banking.beans;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
@Entity
public class Account {
	private long pinNumber;
	private String accountType,accountStatus;
	private float accountBalance;
	@OneToMany(mappedBy="account")
	@MapKey
	public Map<Integer,Transactions>transactions = new HashMap<Integer, Transactions>();	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long accountNo;
	
@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", pinNumber=" + pinNumber + ", accountType=" + accountType
				+ ", accountStatus=" + accountStatus + ", accountBalance=" + accountBalance + ", transactions="
				+ transactions + "]";
	}


public Account(String accountType, float accountBalance) {
	super();
	this.accountType = accountType;
	this.accountBalance = accountBalance;
}

public Account() {
	super();
}


public Account(String accountType, float accountBalance,long pinNumber) {
	super();
	this.accountType = accountType;
	this.accountBalance = accountBalance;
	this.pinNumber=pinNumber;
}



public long getAccountNo() {
	return accountNo;
}
public void setAccountNo(long accountNo) {
	this.accountNo = accountNo;
}
public long getPinNumber() {
	return pinNumber;
}
public void setPinNumber(long pinNumber) {
	this.pinNumber = pinNumber;
}
public String getAccountType() {
	return accountType;
}
public void setAccountType(String accountType) {
	this.accountType = accountType;
}
public String getAccountStatus() {
	return accountStatus;
}
public void setAccountStatus(String accountStatus) {
	this.accountStatus = accountStatus;
}
public float getAccountBalance() {
	return accountBalance;
}
public void setAccountBalance(float accountBalance) {
	this.accountBalance = accountBalance;
}
public Map<Integer, Transactions> getTransactions() {
	return transactions;
}
public void setTransactions(Map<Integer,Transactions> transactions) {
	this.transactions = transactions;
}


}
